# Skill Exchange Platform

## How to Run Locally

### 1. Backend

```bash
cd backend
npm install
node server.js
```

Backend runs on [http://localhost:4000](http://localhost:4000)

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on [http://localhost:5173](http://localhost:5173)

### 3. Explore!

Open [http://localhost:5173](http://localhost:5173) in your browser.

- The app will show user matches for skill exchange.
- To add users and skills, use a tool like [Postman](https://www.postman.com/) or [Insomnia](https://insomnia.rest/) to POST to:
  - `POST http://localhost:4000/api/users` (body: `{ "name": "Alice", "email": "...", "bio": "..." }`)
  - `POST http://localhost:4000/api/skills` (body: `{ "name": "React", "type": "teach", "UserId": 1 }`)

---

**If you need help with adding forms for users/skills, authentication, or deployment—just ask!**