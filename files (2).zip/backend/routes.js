import express from "express";
import { User, Skill, Session } from "./models.js";
const router = express.Router();

// Add a user
router.post("/users", async (req, res) => {
  const user = await User.create(req.body);
  res.json(user);
});

// List users
router.get("/users", async (req, res) => {
  const users = await User.findAll({ include: { model: Skill, as: "skills" } });
  res.json(users);
});

// Add skill to user
router.post("/skills", async (req, res) => {
  const skill = await Skill.create(req.body);
  res.json(skill);
});

// Find skill matches (simple logic)
router.get("/matches", async (req, res) => {
  const teachSkills = await Skill.findAll({ where: { type: "teach" } });
  const learnSkills = await Skill.findAll({ where: { type: "learn" } });

  const matches = [];
  teachSkills.forEach((teach) => {
    learnSkills.forEach((learn) => {
      if (
        teach.name.toLowerCase() === learn.name.toLowerCase() &&
        teach.UserId !== learn.UserId
      ) {
        matches.push({
          teacher: teach.UserId,
          learner: learn.UserId,
          skill: teach.name,
        });
      }
    });
  });
  res.json(matches);
});

export default router;