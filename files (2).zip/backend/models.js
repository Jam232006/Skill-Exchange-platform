import { Sequelize, DataTypes } from "sequelize";
const db = new Sequelize({
  dialect: "sqlite",
  storage: "./db.sqlite",
});

export const User = db.define("User", {
  name: DataTypes.STRING,
  email: DataTypes.STRING,
  bio: DataTypes.TEXT,
});

export const Skill = db.define("Skill", {
  name: DataTypes.STRING,
  type: DataTypes.STRING, // 'teach' or 'learn'
});

export const Session = db.define("Session", {
  date: DataTypes.DATE,
  status: DataTypes.STRING,
});

User.hasMany(Skill, { as: "skills" });
Skill.belongsTo(User);

Session.belongsTo(User, { as: "teacher" });
Session.belongsTo(User, { as: "learner" });
Session.belongsTo(Skill);

export { db };