import { useState, useEffect } from "react";
import SkillMatch from "./components/SkillMatch";

function App() {
  const [users, setUsers] = useState([]);
  const [matches, setMatches] = useState([]);

  useEffect(() => {
    fetch("http://localhost:4000/api/users")
      .then((res) => res.json())
      .then(setUsers);

    fetch("http://localhost:4000/api/matches")
      .then((res) => res.json())
      .then(setMatches);
  }, []);

  return (
    <div style={{ maxWidth: 600, margin: "auto", padding: 20 }}>
      <h1>Skill Exchange Platform</h1>
      <SkillMatch matches={matches} users={users} />
    </div>
  );
}

export default App;