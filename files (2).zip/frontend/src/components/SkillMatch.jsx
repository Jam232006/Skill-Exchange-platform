function SkillMatch({ matches, users }) {
  const getUser = (id) => users.find((u) => u.id === id);
  return (
    <div>
      <h2>Skill Matches</h2>
      <ul>
        {matches.map((m, i) => (
          <li key={i}>
            {getUser(m.teacher)?.name} can teach "{m.skill}" to {getUser(m.learner)?.name}
          </li>
        ))}
      </ul>
    </div>
  );
}
export default SkillMatch;